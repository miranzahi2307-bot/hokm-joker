# Hokm Joker Dual-Mode Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Rebuild Hokm Joker as a reliable mobile-first card game supporting both offline 1-human+5-AI play and local Wi-Fi play.

**Architecture:** Separate the deterministic rules engine from React UI. Keep game state serializable so the same state model can drive offline AI and a local-network host/client transport later. Persist only profile/settings/history/unlocks locally; never require internet.

**Tech Stack:** React, Vite, plain JavaScript, browser local storage, local transport abstraction.

**Spec:** Approved chat design for Hokm Joker dual-mode app.

## Global Constraints
- 6 players, 2 teams of 3.
- 52 cards + 2 jokers = 54; 9 cards per player.
- 9 tricks per hand; target score 540.
- Offline mode: 1 human + 5 AI.
- Wi-Fi mode: local-network play without internet.
- Bidding: 6/7/8/pass with dealer no-pass/surrender.
- Black/red joker rules and KOT are enforced by the engine.
- No negative scoring.
- Profile/settings/history/unlocks persist locally.

### Task 1: Deterministic rules engine
**Files:** `src/gameEngine.js`, `src/gameEngine.test.js`
- [ ] Add failing tests for deck/deal.
- [ ] Add bidding/dealer tests.
- [ ] Add suit/joker tests.
- [ ] Add KOT/scoring tests.
- [ ] Implement pure deterministic rules.
- [ ] Run tests.

### Task 2: Offline controller and AI
**Files:** `src/gameController.js`, `src/aiPlayer.js`, `src/gameController.test.js`, `src/main.jsx`
- [ ] Test complete 9-trick controller flow.
- [ ] Test AI legal decisions.
- [ ] Implement controller transitions.
- [ ] Implement deterministic legal AI.
- [ ] Connect React state.
- [ ] Run tests.

### Task 3: UI and local persistence
**Files:** `src/main.jsx`, `src/styles.css`, `src/storage.js`
- [ ] Test storage.
- [ ] Implement profile/settings/history/unlocks.
- [ ] Implement preparation/team editing.
- [ ] Implement table, score panel and result.
- [ ] Implement gallery and guide.
- [ ] Verify mobile layout.

### Task 4: Wi-Fi local multiplayer
**Files:** `src/network/protocol.js`, `src/network/transport.js`, `src/network/host.js`, `src/network/client.js`, `src/gameController.js`, `src/main.jsx`
- [ ] Test versioned join/ready/command/state/leave protocol.
- [ ] Implement authoritative host model.
- [ ] Implement client command transport.
- [ ] Add lobby/room UI.
- [ ] Test multiple local browser instances where supported.

### Task 5: Audio, animation and unlock polish
**Files:** `src/main.jsx`, `src/styles.css`, `src/audio.js`
- [ ] Add independent music/SFX controls.
- [ ] Add card/turn/collection/win/KOT effects.
- [ ] Add unlock conditions.
- [ ] Verify effects are state-independent.

### Task 6: Release verification
**Files:** `package.json`, `README.md`
- [ ] Install dependencies.
- [ ] Run all tests.
- [ ] Run production build.
- [ ] Smoke-test build.
- [ ] Package verified project ZIP.
- [ ] Leave Android wrapper/APK as the next release step.
