# حکم‌جوکر V5

بازی حکم ۶ نفره با دو حالت: آفلاین با ۵ هوش مصنوعی و بازی محلی Wi-Fi بدون اینترنت.

## وضعیت
- هسته قوانین و تست‌های Node آماده است.
- پروتکل پیام نسخه‌دار آماده است.
- اتصال محلی WebRTC با سیگنالینگ دستی برای نمونه اولیه آماده است.
- Build نهایی نیازمند دسترسی npm به registry است.

## تست
`node src/gameEngine.test.js`
`node src/gameController.test.js`
`node src/network/protocol.test.js`
`node src/network/webrtc.test.js`
