# حکم‌جوکر — Final Release Gate

This project must not be called final until every gate below is green.

## Game
- [x] 6 players / 2 teams of 3
- [x] 54-card deck / 9 cards each
- [x] 6→7→8 bidding and dealer no-pass rule
- [x] 10-second auction timeout
- [x] trump selection
- [x] mandatory follow-suit
- [x] black/red joker rules and black deadline
- [x] KOT immediate win/loss logic
- [x] 540 target and immediate game end
- [x] next-hand dealer selection

## Client
- [x] offline AI path
- [x] preparation/team assignment
- [x] profile/settings/guide
- [x] mobile table UI
- [x] persistent local profile storage

## Local multiplayer
- [x] versioned message protocol
- [x] WebRTC transport scaffolding
- [ ] polished multi-device lobby/game-state synchronization
- [ ] Android local-network integration test with multiple physical devices

## Android
- [x] native WebView shell
- [x] release Gradle project
- [x] CI workflow that installs web dependencies, builds web assets, and assembles APK
- [ ] successful Android CI build
- [ ] install/launch smoke test on physical Android device

## Final gate
Do not distribute a final APK until the remaining unchecked gates are verified.
