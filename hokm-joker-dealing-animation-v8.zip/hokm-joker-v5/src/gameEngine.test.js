import assert from 'node:assert/strict';
import {makeDeck,dealAll,bidLegal,canPlayCard,winningPlay,isBlackDeadlineFailure,scoreBid,dealerForNextHand} from './gameEngine.js';
const deck=makeDeck(()=>.5); assert.equal(deck.length,54); assert.equal(new Set(deck.map(c=>c.id)).size,54); assert.deepEqual(dealAll(deck).map(h=>h.length),[9,9,9,9,9,9]);
assert.equal(bidLegal(null,6),true); assert.equal(bidLegal(6,6),false); assert.equal(bidLegal(7,6),false); assert.equal(bidLegal(7,8),true);
const hearts={id:'h-a',kind:'normal',suit:'hearts',rank:'A'}; const spade={id:'s-k',kind:'normal',suit:'spades',rank:'K'}; const red={id:'joker-red',kind:'joker',joker:'red'}; const black={id:'joker-black',kind:'joker',joker:'black'};
assert.equal(canPlayCard({hand:[hearts,spade],card:spade,trick:[{playerId:0,card:hearts}],leadSuit:'hearts'}),false);
assert.equal(canPlayCard({hand:[red,spade],card:red,trick:[{playerId:0,card:hearts}],leadSuit:'hearts',blackPlayed:false}),false);
assert.equal(canPlayCard({hand:[red,spade],card:red,trick:[{playerId:0,card:black}],leadSuit:'hearts',blackPlayed:false}),true);
assert.equal(winningPlay([{playerId:0,card:spade},{playerId:1,card:black}],{trump:'hearts',leadSuit:'spades'}).playerId,1);
assert.equal(winningPlay([{playerId:0,card:black},{playerId:1,card:red}],{trump:'hearts',leadSuit:'spades'}).playerId,1);
assert.equal(isBlackDeadlineFailure({hands:[[black],[],[],[],[],[]],blackPlayed:false,trickNumber:3}),true);
assert.deepEqual(scoreBid(7,false),{team:0,opponent:140}); assert.equal(dealerForNextHand({scores:[500,300],previousDealer:2,players:[{team:0},{team:1},{team:0},{team:1},{team:0},{team:1}]}),1);
console.log('gameEngine tests: PASS');

// End-condition semantics
assert.deepEqual(scoreBid(6,true),{team:60,opponent:0});
assert.deepEqual(scoreBid(6,false),{team:0,opponent:120});
assert.equal(isBlackDeadlineFailure({hands:Array.from({length:6},()=>[]),blackPlayed:true,trickNumber:3}),false);
const blackHeld=Array.from({length:6},()=>[]); blackHeld[2]=[{id:'joker-black'}];
assert.equal(isBlackDeadlineFailure({hands:blackHeld,blackPlayed:false,trickNumber:3}),true);

