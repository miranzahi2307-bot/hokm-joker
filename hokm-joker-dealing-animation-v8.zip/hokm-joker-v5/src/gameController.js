export const resolveBlackLoss=({scores,losingTeam})=>({scores:[...scores],winner:1-losingTeam,ended:true,reason:'black-joker'});
export const resolveKotLoss=({scores,declarerTeam})=>({scores:[...scores],winner:1-declarerTeam,ended:true,reason:'kot'});
export const resolveKotWin=({scores,declarerTeam})=>({scores:[...scores],winner:declarerTeam,ended:true,reason:'kot-win'});

import {makeDeck,dealAll,nextPlayer,bidLegal,canPlayCard,winningPlay,isBlackDeadlineFailure,scoreBid,dealerForNextHand,TARGET_SCORE,TRICKS,teamOf,teamTricks} from './gameEngine.js';

export function createGameController({players,dealer=0,random=Math.random}={}){
  if(!Array.isArray(players)||players.length!==6) throw new Error('Exactly 6 players are required');
  let state={phase:'idle',players,dealer,round:1,hands:[],auctionIndex:null,passed:[],bid:null,declarer:null,trump:null,trick:[],leadSuit:null,blackPlayed:false,trickWinners:[],trickCounts:Array(6).fill(0),scores:[0,0],kot:null,current:null,countdown:null,lastWinner:null,ended:false,dealtCount:0,dealSerial:0,lastDealtPlayer:null};
  const emit=()=>structuredClone(state);
  const set=patch=>(state={...state,...patch},emit());
  const activeAfter=(pid,passed=state.passed)=>{let p=nextPlayer(pid);for(let i=0;i<6;i++){if(!passed.includes(p))return p;p=nextPlayer(p)}return null};
  const startHand=()=>{if(state.ended)return emit();const hands=dealAll(makeDeck(random));return set({phase:'deal',hands,auctionIndex:nextPlayer(state.dealer),passed:[],bid:null,declarer:null,trump:null,trick:[],leadSuit:null,blackPlayed:false,trickWinners:[],trickCounts:Array(6).fill(0),kot:null,current:null,countdown:null,lastWinner:null,dealtCount:0,dealSerial:0,lastDealtPlayer:null})};
  const dealStep=()=>{if(state.phase!=='deal')return emit();const dealt=state.dealtCount+1;const pid=(dealt-1)%6;return set({dealtCount:dealt,dealSerial:state.dealSerial+1,lastDealtPlayer:pid,phase:dealt>=54?'dealView':'deal',countdown:dealt>=54?10:null})};
  const tickDealView=()=>{if(state.phase!=='dealView')return emit();const next=Math.max(0,(state.countdown??10)-1);return set({countdown:next,phase:next===0?'dealReady':'dealView'})};
  const beginAuction=()=>state.phase==='dealReady'?set({phase:'auction',countdown:10}):emit();
  const submitBid=(pid,value)=>{
    if(state.phase!=='auction'||state.auctionIndex!==pid)return emit();
    if(value==='pass'){
      if(pid===state.dealer&&state.bid===null)return set({phase:'surrender',countdown:null});
      const passed=[...new Set([...state.passed,pid])];
      const remaining=state.players.map((_,i)=>i).filter(i=>!passed.includes(i));
      if(state.bid===null&&remaining.length===1)return set({passed,bid:6,declarer:remaining[0],phase:'trump',countdown:null});
      return set({passed,auctionIndex:activeAfter(pid,passed),countdown:10});
    }
    if(!bidLegal(state.bid,value))return emit();
    if(value===8)return set({bid:8,declarer:pid,phase:'trump',countdown:null});
    return set({bid:value,declarer:pid,auctionIndex:activeAfter(pid,state.passed),countdown:10});
  };
  const tickAuction=()=>{
    if(state.phase!=='auction')return emit();
    const next=Math.max(0,(state.countdown??10)-1);
    if(next>0)return set({countdown:next});
    const active=state.players.map((_,i)=>i).filter(i=>!state.passed.includes(i));
    if(active.length===1 && active[0]===state.auctionIndex){
      const minimum=state.bid===null?6:state.bid+1;
      return set({bid:Math.min(8,minimum),declarer:state.auctionIndex,phase:'trump',countdown:null});
    }
    return submitBid(state.auctionIndex,'pass');
  };
  const surrender=()=>{if(state.phase!=='surrender')return emit();const dealerTeam=teamOf(state.players,state.dealer);const scores=[...state.scores];scores[1-dealerTeam]+=60;const ended=scores.some(x=>x>=TARGET_SCORE);return set({scores,ended,phase:ended?'end':'handEnd',winner:ended?(scores[0]>=TARGET_SCORE?0:1):null});};
  const chooseTrump=(pid,suit)=>{if(state.phase!=='trump'||pid!==state.declarer||!suit)return emit();return set({trump:suit,phase:'play',current:nextPlayer(pid),trick:[],leadSuit:null,countdown:null});};
  const finish=(phase,counts,winners,extra={})=>{const declarerTeam=teamOf(state.players,state.declarer);const won=teamTricks(state.players,counts,declarerTeam);const scored=scoreBid(state.bid??6,won>=(state.bid??6));const scores=[...state.scores];scores[declarerTeam]+=scored.team;scores[1-declarerTeam]+=scored.opponent;const winner=scores.findIndex(s=>s>=TARGET_SCORE);return {scores,phase:winner>=0?'end':phase,ended:winner>=0,winner:winner>=0?winner:null,trickWinners:winners,trickCounts:counts,...extra};};
  const playCard=(pid,card)=>{
    if(state.phase!=='play'||pid!==state.current)return emit();
    const hand=state.hands[pid]||[];
    if(!canPlayCard({hand,card,trick:state.trick,leadSuit:state.leadSuit,blackPlayed:state.blackPlayed}))return emit();
    const hands=state.hands.map((h,i)=>i===pid?h.filter(c=>c.id!==card.id):h);
    const trick=[...state.trick,{playerId:pid,card}];
    const blackPlayed=state.blackPlayed||card.id==='joker-black';
    const leadSuit=state.leadSuit??(card.kind==='normal'?card.suit:null);
    if(trick.length<6)return set({hands,trick,leadSuit,blackPlayed,current:nextPlayer(pid)});
    const winner=winningPlay(trick,{trump:state.trump,leadSuit,blackPlayedBefore:state.blackPlayed});
    const counts=[...state.trickCounts];counts[winner.playerId]++;
    const winners=[...state.trickWinners,winner.playerId];
    if(isBlackDeadlineFailure({hands,blackPlayed,trickNumber:winners.length})){const holdingTeam=state.players.findIndex(p=>hands[p.id]?.some(c=>c.id==='joker-black'))>=0?teamOf(state.players,state.players.findIndex(p=>hands[p.id]?.some(c=>c.id==='joker-black'))):null;const losingTeam=holdingTeam===null?0:holdingTeam;const terminal=resolveBlackLoss({scores:state.scores,losingTeam});return set({hands,trick,leadSuit,blackPlayed,trickWinners:winners,trickCounts:counts,phase:'blackLoss',lastWinner:winner.playerId,ended:true,winner:terminal.winner,reason:terminal.reason});}
    if(state.kot?.active&&teamOf(state.players,winner.playerId)!==teamOf(state.players,state.declarer)){const declarerTeam=teamOf(state.players,state.declarer);const terminal=resolveKotLoss({scores:state.scores,declarerTeam});return set({hands,trick,trickWinners:winners,trickCounts:counts,phase:'kotLoss',lastWinner:winner.playerId,ended:true,winner:terminal.winner,reason:terminal.reason});}
    if(winners.length===TRICKS){
      const result=finish(state.kot?.active?'kotWin':'handEnd',counts,winners,{hands,trick,lastWinner:winner.playerId});
      if(state.kot?.active){const terminal=resolveKotWin({scores:state.scores,declarerTeam});return set({...result,phase:'kotWin',ended:true,winner:terminal.winner,reason:terminal.reason});} return set(result);
    }
    const declarerTeam=teamOf(state.players,state.declarer);
    if(!state.kot&&teamOf(state.players,winner.playerId)===declarerTeam&&[6,7,8].includes(winners.length))return set({hands,trick:[],leadSuit:null,blackPlayed,trickWinners:winners,trickCounts:counts,current:winner.playerId,lastWinner:winner.playerId,phase:'kot'});
    return set({hands,trick:[],leadSuit:null,blackPlayed,trickWinners:winners,trickCounts:counts,current:winner.playerId,lastWinner:winner.playerId});
  };
  const answerKot=(pid,yes)=>{if(state.phase!=='kot'||pid!==state.declarer)return emit();return yes?set({kot:{active:true,remaining:TRICKS-state.trickWinners.length},phase:'play'}):set({kot:null,phase:'play'});};
  const nextHand=()=>{if(state.ended)return emit();const dealer=dealerForNextHand({scores:state.scores,previousDealer:state.dealer,players:state.players});return set({round:state.round+1,dealer,phase:'idle',current:null,countdown:null});};
  return {getState:emit,startHand,dealStep,tickDealView,beginAuction,submitBid,tickAuction,surrender,chooseTrump,playCard,answerKot,nextHand};
}
