export const PLAYERS=6;
export const TRICKS=9;
export const TARGET_SCORE=540;
export const SUITS=[
 {id:'spades',s:'♠',name:'پیک',color:'black'},
 {id:'clubs',s:'♣',name:'گیشنیز',color:'black'},
 {id:'diamonds',s:'♦',name:'خشت',color:'red'},
 {id:'hearts',s:'♥',name:'دل',color:'red'}
];
export const RANKS=[2,3,4,5,6,7,8,9,10,'J','Q','K','A'];
export const rankValue=r=>typeof r==='number'?r:{J:11,Q:12,K:13,A:14}[r];
export const nextPlayer=i=>(i+1)%PLAYERS;
export const shuffle=(cards,rng=Math.random)=>{const a=[...cards];for(let i=a.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
export const makeDeck=(rng=Math.random)=>shuffle([
 ...SUITS.flatMap(s=>RANKS.map(r=>({id:`${s.id}-${r}`,kind:'normal',suit:s.id,s:s.s,rank:r}))),
 {id:'joker-red',kind:'joker',joker:'red',s:'★',rank:15},
 {id:'joker-black',kind:'joker',joker:'black',s:'★',rank:16}
],rng);
export const cardSort=(a,b)=>{if(a.kind!==b.kind)return a.kind==='joker'?1:-1;if(a.kind==='joker')return a.joker==='black'?-1:1;const order={spades:0,clubs:1,diamonds:2,hearts:3};return order[a.suit]-order[b.suit]||rankValue(b.rank)-rankValue(a.rank)};
export const dealAll=(deck=makeDeck())=>{if(deck.length!==54)throw new Error('54-card deck required');const hands=Array.from({length:PLAYERS},()=>[]);deck.forEach((c,i)=>hands[i%PLAYERS].push(c));return hands.map(h=>h.sort(cardSort))};
export const bidLegal=(current,bid)=>Number.isInteger(bid)&&bid>=6&&bid<=8&&(!current||bid>current);
export const bidPoints=(bid,success)=>success?bid*10:bid*20;
export const canPlayCard=({hand,card,trick=[],leadSuit=null,blackPlayed=false})=>{
 if(!card||!hand.some(c=>c.id===card.id))return false;
 if(!trick.length)return card.kind==='normal'||(card.kind==='joker'&&card.joker==='red'&&hand.length===1);
 if(card.kind==='joker'){
   if(card.joker==='black')return true;
   return blackPlayed||trick.some(p=>p.card.kind==='joker'&&p.card.joker==='black');
 }
 if(!leadSuit)return true;
 const hasLead=hand.some(c=>c.kind==='normal'&&c.suit===leadSuit);
 return !hasLead||card.suit===leadSuit;
};
export const winningPlay=(plays,{trump,leadSuit,blackPlayedBefore=false}={})=>{
 const blackInTrick=plays.some(p=>p.card.kind==='joker'&&p.card.joker==='black');
 const red=plays.find(p=>p.card.kind==='joker'&&p.card.joker==='red'&&(blackPlayedBefore||blackInTrick));
 if(red)return red;
 const black=plays.find(p=>p.card.kind==='joker'&&p.card.joker==='black');
 if(black)return black;
 const normals=plays.filter(p=>p.card.kind==='normal');
 const tr=normals.filter(p=>p.card.suit===trump);
 const pool=tr.length?tr:normals.filter(p=>p.card.suit===leadSuit);
 if(!pool.length) return plays[0];
 return pool.reduce((best,p)=>rankValue(p.card.rank)>rankValue(best.card.rank)?p:best,pool[0]);
};
export const isBlackDeadlineFailure=({hands,blackPlayed,trickNumber})=>trickNumber>=3&&!blackPlayed&&hands.some(h=>h.some(c=>c.id==='joker-black'));
export const scoreBid=(bid,success)=>({team:success?bid*10:0,opponent:success?0:bid*20});
export const dealerForNextHand=({scores,previousDealer,players})=>{if(scores[0]===scores[1])return previousDealer;const losingTeam=scores[0]<scores[1]?0:1;const candidate=players.findIndex(p=>p.team===losingTeam);return candidate<0?previousDealer:candidate};
export const teamOf=(players,pid)=>players[pid]?.team??0;
export const teamTricks=(players,trickCounts,team)=>trickCounts.reduce((n,c,i)=>n+(players[i]?.team===team?c:0),0);
