const KEY='hokmJokerProfile';
export const DEFAULT_PROFILE={name:'حسن',avatar:'👤',music:true,sfx:true,volume:.7,theme:'green',handGap:'normal',wins:0,losses:0,kotWins:0,kotLosses:0,history:[],teamHistory:[],unlocks:[0]};
export function loadProfile(){try{return {...DEFAULT_PROFILE,...JSON.parse(localStorage.getItem(KEY)||'{}')}}catch{return {...DEFAULT_PROFILE}}}
export function saveProfile(p){localStorage.setItem(KEY,JSON.stringify(p));}
