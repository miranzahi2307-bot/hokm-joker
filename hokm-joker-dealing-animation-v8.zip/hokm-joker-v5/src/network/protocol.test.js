import assert from 'node:assert/strict';import {encode,decode} from './protocol.js';
const m=decode(encode('join',{name:'حسن'}));assert.equal(m.v,1);assert.equal(m.type,'join');assert.equal(m.payload.name,'حسن');assert.throws(()=>decode('{"v":99,"type":"join"}'));console.log('protocol tests: PASS');
