import {encode,decode} from './protocol.js';
const waitIce=pc=>new Promise(resolve=>{
 if(pc.iceGatheringState==='complete') return resolve();
 const done=()=>{if(pc.iceGatheringState==='complete'){pc.removeEventListener('icegatheringstatechange',done);resolve();}};
 pc.addEventListener('icegatheringstatechange',done);
 setTimeout(()=>{pc.removeEventListener('icegatheringstatechange',done);resolve();},5000);
});
export async function createClient(offer){
 if(!globalThis.RTCPeerConnection) throw new Error('WebRTC unavailable');
 const pc=new RTCPeerConnection({iceServers:[]}); let channel=null; const listeners=[];
 pc.addEventListener('datachannel',e=>{channel=e.channel;channel.addEventListener('message',m=>{try{listeners.forEach(fn=>fn(decode(m.data)))}catch{}})});
 await pc.setRemoteDescription(offer); const answer=await pc.createAnswer(); await pc.setLocalDescription(answer); await waitIce(pc);
 const transport={send:(type,payload={})=>{if(!channel||channel.readyState!=='open')throw new Error('Channel not open');channel.send(encode(type,payload))},on:fn=>{listeners.push(fn);return()=>{const i=listeners.indexOf(fn);if(i>=0)listeners.splice(i,1)}},close:()=>pc.close(),ready:()=>!!channel&&channel.readyState==='open'};
 return {pc,answer:pc.localDescription,transport};
}
