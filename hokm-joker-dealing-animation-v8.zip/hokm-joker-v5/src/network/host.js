import {encode,decode} from './protocol.js';

const waitIce=pc=>new Promise(resolve=>{
 if(pc.iceGatheringState==='complete') return resolve();
 const done=()=>{if(pc.iceGatheringState==='complete'){pc.removeEventListener('icegatheringstatechange',done);resolve();}};
 pc.addEventListener('icegatheringstatechange',done);
 setTimeout(()=>{pc.removeEventListener('icegatheringstatechange',done);resolve();},5000);
});

export async function createHost(){
 if(!globalThis.RTCPeerConnection) throw new Error('WebRTC unavailable');
 const pc=new RTCPeerConnection({iceServers:[]});
 const channel=pc.createDataChannel('hokm-joker',{ordered:true});
 const listeners=[];
 channel.addEventListener('message',e=>{try{listeners.forEach(fn=>fn(decode(e.data)))}catch{}});
 const transport={send:(type,payload={})=>channel.send(encode(type,payload)),on:fn=>{listeners.push(fn);return()=>{const i=listeners.indexOf(fn);if(i>=0)listeners.splice(i,1)}},close:()=>pc.close(),ready:()=>channel.readyState==='open'};
 const offer=await pc.createOffer(); await pc.setLocalDescription(offer); await waitIce(pc);
 return {pc,offer:pc.localDescription,transport};
}
export async function acceptAnswer(pc,answer){await pc.setRemoteDescription(answer);}
