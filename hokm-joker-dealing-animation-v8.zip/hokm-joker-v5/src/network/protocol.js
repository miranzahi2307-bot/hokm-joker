export const PROTOCOL_VERSION=1;
export const TYPES=['join','ready','command','state','leave','ping','error'];
export function encode(type,payload={}){if(!TYPES.includes(type))throw new Error('Unknown message type');return JSON.stringify({v:PROTOCOL_VERSION,type,payload})}
export function decode(raw){const m=typeof raw==='string'?JSON.parse(raw):raw;if(m?.v!==PROTOCOL_VERSION||!TYPES.includes(m.type))throw new Error('Invalid protocol message');return m}
