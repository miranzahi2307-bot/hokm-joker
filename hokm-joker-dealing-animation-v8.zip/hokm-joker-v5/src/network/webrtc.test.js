import assert from 'node:assert/strict';
import {createHost} from './host.js';
assert.equal(typeof createHost,'function');
console.log('webrtc module test: PASS');
