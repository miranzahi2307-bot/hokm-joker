import assert from 'node:assert/strict';
import {createGameController} from './gameController.js';
const players=Array.from({length:6},(_,i)=>({id:i,name:`P${i}`,team:i%2,human:i===0}));
const c=createGameController({players,dealer:0,random:()=>0.123});
let s=c.startHand(); assert.equal(s.phase,'dealWait'); assert.deepEqual(s.hands.map(h=>h.length),[9,9,9,9,9,9]);
s=c.beginAuction(); assert.equal(s.phase,'auction'); assert.equal(s.countdown,10);
for(let i=0;i<10;i++) s=c.tickAuction(); assert.ok(['surrender','trump','auction'].includes(s.phase));
const c2=createGameController({players,dealer:0,random:()=>0.321}); c2.startHand(); c2.beginAuction();
let x=c2.getState(); const first=x.auctionIndex; x=c2.submitBid(first,6); assert.equal(x.bid,6); assert.equal(x.countdown,10); x=c2.submitBid(x.auctionIndex,'pass'); assert.equal(x.phase,'auction');
console.log('gameController tests: PASS');

// Immediate terminal outcomes must end the whole game, not merely the hand.
const terminalPlayers=Array.from({length:6},(_,i)=>({id:i,name:`P${i}`,team:i%2}));
const blackLossController=createGameController({players:terminalPlayers});
let terminal=blackLossController.getState();
assert.equal(terminal.ended,false);
// Public helpers are pure and make terminal semantics directly testable.
const {resolveBlackLoss,resolveKotLoss}=await import('./gameController.js');
assert.deepEqual(resolveBlackLoss({scores:[100,200],losingTeam:0}),{scores:[100,200],winner:1,ended:true,reason:'black-joker'});
assert.deepEqual(resolveKotLoss({scores:[100,200],declarerTeam:0}),{scores:[100,200],winner:1,ended:true,reason:'kot'});
console.log('terminal outcome tests: PASS');

// Auction timeout: the final eligible player auto-bids the minimum and becomes declarer.
const timeoutController=createGameController({players:terminalPlayers,dealer:0,random:()=>0.111});
timeoutController.startHand(); timeoutController.beginAuction();
let ts=timeoutController.getState();
// Make every player before the dealer pass so dealer is the final bidder with no bid.
for(let i=0;i<5;i++){
  ts=timeoutController.getState();
  if(ts.phase!=='auction') break;
  ts=timeoutController.submitBid(ts.auctionIndex,'pass');
}
if(ts.phase==='auction'){
  for(let i=0;i<10;i++) ts=timeoutController.tickAuction();
  assert.equal(ts.phase,'trump');
  assert.equal(ts.bid,6);
  assert.equal(ts.declarer,ts.auctionIndex);
}
console.log('auction timeout tests: PASS');

// If the last bidder times out after a 6, minimum legal bid is 7 (not pass).
const lastTimeout=createGameController({players:terminalPlayers,dealer:0,random:()=>0.222});
lastTimeout.startHand(); lastTimeout.beginAuction();
let ls=lastTimeout.getState();
ls=lastTimeout.submitBid(ls.auctionIndex,6);
while(ls.phase==='auction'){
  const active=terminalPlayers.map((_,i)=>i).filter(i=>!ls.passed.includes(i));
  if(active.length===1) break;
  ls=lastTimeout.submitBid(ls.auctionIndex,'pass');
}
for(let i=0;i<10;i++) ls=lastTimeout.tickAuction();
assert.equal(ls.phase,'trump');
assert.equal(ls.bid,7);
console.log('final bidder timeout tests: PASS');
