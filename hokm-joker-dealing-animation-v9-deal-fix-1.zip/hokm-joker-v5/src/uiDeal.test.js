import fs from 'node:fs';
import assert from 'node:assert/strict';

const jsx=fs.readFileSync(new URL('./main.jsx',import.meta.url),'utf8');
const css=fs.readFileSync(new URL('./styles.css',import.meta.url),'utf8');
const workflow=fs.readFileSync(new URL('../.github/workflows/android.yml',import.meta.url),'utf8');

assert.match(jsx,/function HumanDealHand/,'deal preview must have a dedicated human hand');
assert.match(jsx,/state\.phase==='dealView'.*showHumanHand/s,'deal preview must render the human hand');
assert.match(jsx,/auctionPanel/,'auction UI must use the compact auction panel');
assert.match(css,/\.humanDealHand/,'human deal-preview hand styling must exist');
assert.match(workflow,/unzip -q hokm-joker-dealing-animation-v9-deal-fix\.zip/,'CI must build from the uploaded v9 source archive');
assert.match(workflow,/grep -q "HumanDealHand"/,'CI must verify it extracted the new source before building');
assert.doesNotMatch(workflow,/npm install --no-audit --no-fund\n      - run: npm run build/,'CI must not build the repository root before extracting the source archive');
console.log('ui deal/build-source tests: PASS');
