import React,{useEffect,useMemo,useState} from 'react';
import {createRoot} from 'react-dom/client';
import './styles.css';
import {SUITS,shuffle,canPlayCard} from './gameEngine.js';
import {chooseBid,chooseTrump,chooseCard,shouldAcceptKot} from './aiPlayer.js';
import {createGameController} from './gameController.js';
import {loadProfile,saveProfile} from './storage.js';

const AI_NAMES=['رضا','علی','مهدی','سامان','امیر','پوریا','حامد','مجتبی','میلاد','فرید','نوید','سعید'];
const AVATARS=['👤','🧔','👨‍🦱','👨‍💼','🥷','🧑‍🎤','🤠','🧑‍🚀','🧑‍🎨','🧑‍🔧','🧑‍🍳','🧑‍🏫'];
const teamNames=['تیم اول','تیم دوم'];
function seats(name,avatar){const names=shuffle(AI_NAMES).slice(0,5);return [{id:0,name,avatar,human:true,team:0},...names.map((n,i)=>({id:i+1,name:n,avatar:AVATARS[i+1],human:false,team:(i+1)%2}))];}
function App(){
 const [profile,setProfile]=useState(loadProfile);const [screen,setScreen]=useState('home');const [players,setPlayers]=useState([]);const [prepTeams,setPrepTeams]=useState(teamNames);const [controller,setController]=useState(null);const [state,setState]=useState(null);const [wifi,setWifi]=useState({mode:'menu',offer:'',answer:''});
 useEffect(()=>saveProfile(profile),[profile]);
 const start=()=>{const ps=seats(profile.name,profile.avatar);setPlayers(ps);setScreen('prep')};
 const launchPrepared=()=>{const c=createGameController({players});setController(c);setState(c.startHand());setScreen('game')};
 const refresh=fn=>setState(fn());
 const suitById=id=>SUITS.find(s=>s.id===id);
 if(screen==='home')return <Home onStart={start} onWifi={()=>setScreen('wifi')} on={()=>setScreen('profile')} setScreen={setScreen}/>;
 if(screen==='prep')return <Prep players={players} setPlayers={setPlayers} teamNames={prepTeams} setTeamNames={setPrepTeams} onStart={launchPrepared} onBack={()=>setScreen('home')}/>;
 if(screen==='profile')return <Page title="پروفایل" back={()=>setScreen('home')}><div className="profile"><div className="bigAvatar">{profile.avatar}</div><input value={profile.name} onChange={e=>setProfile({...profile,name:e.target.value})}/></div><div className="stats"><b>بازی {profile.wins+profile.losses}</b><b>برد {profile.wins}</b><b>باخت {profile.losses}</b><b>کُت {profile.kotWins}</b></div><div className="avatars">{AVATARS.map(a=><button onClick={()=>setProfile({...profile,avatar:a})}>{a}</button>)}</div></Page>;
 if(screen==='guide')return <Page title="راهنمای بازی" back={()=>setScreen('home')}><p>۵۴ کارت، ۶ بازیکن، ۹ دور. باید خال شروع را دنبال کنی.</p><p>جوکر سیاه تا پایان دور سوم باید بازی شود؛ قرمز بعد از سیاه قوی‌ترین است.</p><p>اعلام: ۶، ۷، ۸. هدف بازی رسیدن به ۵۴۰ امتیاز است.</p></Page>;
 if(screen==='settings')return <Page title="تنظیمات" back={()=>setScreen('home')}><label>موسیقی <input type="checkbox" checked={profile.music} onChange={e=>setProfile({...profile,music:e.target.checked})}/></label><label>صدا <input type="checkbox" checked={profile.sfx} onChange={e=>setProfile({...profile,sfx:e.target.checked})}/></label><label>تم میز <select value={profile.theme} onChange={e=>setProfile({...profile,theme:e.target.value})}><option>green</option><option>blue</option><option>red</option><option>dark</option></select></label></Page>;
 if(screen==='wifi')return <Wifi onBack={()=>setScreen('home')} wifi={wifi} setWifi={setWifi}/>;
 if(screen==='game'&&state)return <Game state={state} players={players} controller={controller} refresh={refresh} profile={profile} setProfile={setProfile} onHome={()=>setScreen('home')} suitById={suitById}/>;
 return null;
}

function Prep({players,setPlayers,teamNames,setTeamNames,onStart,onBack}){
 const reroll=()=>setPlayers(seats(players.find(p=>p.human)?.name||'حسن',players.find(p=>p.human)?.avatar||'👤'));
 const flip=id=>setPlayers(players.map(p=>p.id===id?{...p,team:p.team?0:1}:p));
 const count0=players.filter(p=>p.team===0).length;
 const canStart=count0===3;
 return <div className="app page prep"><button className="back" onClick={onBack}>← بازگشت</button><section className="panel"><h1>آماده‌سازی بازی</h1><div className="teamInputs">{teamNames.map((n,i)=><label>نام تیم {i+1}<input value={n} onChange={e=>setTeamNames(teamNames.map((x,j)=>j===i?e.target.value:x))}/></label>)}</div><button onClick={reroll}>🔀 تصادفی‌سازی دوباره</button><div className="prepTeams">{[0,1].map(t=><div className="prepTeam"><h2>{teamNames[t]} <small>{players.filter(p=>p.team===t).length}/۳</small></h2>{players.filter(p=>p.team===t).map(p=><button className={p.human?'humanPrep':''} disabled={p.human} onClick={()=>flip(p.id)}><span>{p.avatar}</span>{p.name}{p.human?' · شما':''}</button>)}</div>)}</div><p className="hint">برای تغییر تیم، روی نام بازیکن هوش مصنوعی بزن.</p><button className="gold huge" disabled={!canStart} onClick={onStart}>شروع بازی</button></section></div>
}
function Home({onStart,onWifi,setScreen}){return <div className="app home"><img className="appLogo" src="./logo.png" alt="حکم‌جوکر"/><div className="logo">حکم‌جوکر</div><div className="slogan">بازی کن، حاکم شو! 👑</div><button className="gold huge" onClick={onStart}>🎮 بازی آفلاین</button><button className="wide" onClick={onWifi}>📶 بازی با دوستان (Wi‑Fi)</button><button onClick={()=>setScreen('profile')}>👤 پروفایل</button><button onClick={()=>setScreen('settings')}>⚙️ تنظیمات</button><button onClick={()=>setScreen('guide')}>📖 راهنمای بازی</button><footer>V1.0.0</footer></div>}
function Page({title,back,children}){return <div className="app page"><button className="back" onClick={back}>← بازگشت</button><section className="panel"><h1>{title}</h1>{children}</section></div>}
function playDealSound(delay=0,volume=.7){
 setTimeout(()=>{
  try{
   const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;
   const ctx=window.__hokmAudio||(window.__hokmAudio=new AC());if(ctx.state==='suspended')ctx.resume();
   const now=ctx.currentTime,osc=ctx.createOscillator(),gain=ctx.createGain();
   osc.type='triangle';osc.frequency.setValueAtTime(190,now);osc.frequency.exponentialRampToValueAtTime(95,now+.07);
   gain.gain.setValueAtTime(.0001,now);gain.gain.exponentialRampToValueAtTime(Math.max(.015,Math.min(.08,volume*.075)),now+.008);gain.gain.exponentialRampToValueAtTime(.0001,now+.09);
   osc.connect(gain).connect(ctx.destination);osc.start(now);osc.stop(now+.1);
  }catch{}
 },delay);
}
function CardFace({card,back=false,compact=false}){
 if(back)return <div className={`cardFace backCard ${compact?'compact':''}`}><span>ح</span><small>جوکر</small></div>;
 if(card.kind==='joker')return <div className={`cardFace jokerCard ${card.joker}`}><b>★</b><strong>JOKER</strong><small>{card.joker==='red'?'قرمز':'سیاه'}</small></div>;
 const suit=suitByIdLocal(card.suit);
 const court=['J','Q','K'].includes(String(card.rank));
 return <div className={`cardFace ${suit.color} ${court?'courtCard':''} ${compact?'compact':''}`}>
   <div className="cardCorner"><b>{card.rank}</b><span>{suit.s}</span></div>
   {court?<div className="courtArt"><span>♛</span><b>{card.rank}</b><span>{suit.s}</span></div>:<div className="pipArt">{pipPattern(card.rank,suit.s)}</div>}
   <div className="cardCorner bottom"><b>{card.rank}</b><span>{suit.s}</span></div>
 </div>
}
function suitByIdLocal(id){return SUITS.find(s=>s.id===id)||SUITS[0]}
function pipPattern(rank,suit){const n=Number(rank);if(!Number.isInteger(n)||n<2||n>10)return suit;return Array.from({length:n},(_,i)=><span key={i}>{suit}</span>)}
function Game({state,players,controller,refresh,profile,setProfile,onHome,suitById}){
 const [selected,setSelected]=useState(null);
 useEffect(()=>{if(state?.phase!=='deal'||!controller)return;if(profile.sfx){playDealSound(0,profile.volume);playDealSound(95,profile.volume);playDealSound(190,profile.volume);playDealSound(285,profile.volume);playDealSound(380,profile.volume);playDealSound(475,profile.volume)}const t=setTimeout(()=>refresh(controller.dealStep),720);return()=>clearTimeout(t)},[state?.phase,controller]);
 useEffect(()=>{if(state?.phase!=='dealView'||!controller)return;const t=setInterval(()=>refresh(controller.tickDealView),1000);return()=>clearInterval(t)},[state?.phase,controller]);
 useEffect(()=>{if(state?.phase!=='auction'||!controller)return;const t=setInterval(()=>refresh(controller.tickAuction),1000);return()=>clearInterval(t)},[state?.phase,controller]);
 useEffect(()=>{if(!controller||!state)return;if(state.phase==='auction'&&players[state.auctionIndex]&&!players[state.auctionIndex].human){const t=setTimeout(()=>{const v=chooseBid({hand:state.hands[state.auctionIndex]||[],currentBid:state.bid});refresh(()=>controller.submitBid(state.auctionIndex,v??'pass'))},900);return()=>clearTimeout(t)}if(state.phase==='trump'&&players[state.declarer]&&!players[state.declarer].human){const t=setTimeout(()=>refresh(()=>controller.chooseTrump(state.declarer,chooseTrump(state.hands[state.declarer]||[]))),850);return()=>clearTimeout(t)}if(state.phase==='play'&&players[state.current]&&!players[state.current].human){const pid=state.current;const h=state.hands[pid]||[];const pick=chooseCard({hand:h,trick:state.trick,leadSuit:state.leadSuit,trump:state.trump,blackPlayed:state.blackPlayed});const t=setTimeout(()=>{if(pick)refresh(()=>controller.playCard(pid,pick))},650);return()=>clearTimeout(t)}},[state?.phase,state?.auctionIndex,state?.current,state?.trick,state?.bid]);
 const human=players.find(p=>p.human);const hand=state.hands[human.id]||[];const playable=c=>canPlayCard({hand,card:c,trick:state.trick,leadSuit:state.leadSuit,trump:state.trump,blackPlayed:state.blackPlayed});
 const activePid=state.phase==='auction'?state.auctionIndex:state.phase==='trump'?state.declarer:state.current;
 const showHumanHand=!['deal','idle','dealView','dealReady'].includes(state.phase);
 const act=(f)=>{setSelected(null);refresh(f)};
 return <div className="app game"><header><button>🏆 {state.scores[0]} : {state.scores[1]}</button><b>حکم‌جوکر</b><button onClick={onHome}>⌂</button></header><div className="felt">
  <div className="round">دور {Math.min(9,state.trickWinners.length+1)} از ۹</div>
  {state.trump&&<div className="trump">حکم {suitById(state.trump).s}</div>}
  {players.map(p=><div key={p.id} className={`seat seat${p.id} ${activePid===p.id?'active':''} ${p.human?'humanSeat':''}`}><span className="avatarFace">{p.avatar}</span><small>{p.name}</small><i className={`team t${p.team}`}></i><b>{state.trickCounts[p.id]||0}</b>{activePid===p.id&&<em>{state.phase==='auction'?'نوبت اعلام':state.phase==='trump'?'انتخاب حکم':'نوبت بازی'}</em>}</div>)}
  {state.phase==='deal'&&<DealOverlay players={players}/>} 
  {state.phase==='dealView'&&<><DealFannedHands players={players} hands={state.hands}/><HumanDealHand hand={hand}/><DealReadyOverlay state={state}/></>}
  {state.phase==='dealReady'&&<><DealFannedHands players={players} hands={state.hands} settled/><HumanDealHand hand={hand} settled/><DealReadyOverlay state={state} ready onStart={()=>act(controller.beginAuction)}/></>}
  {state.phase==='auction'&&<div className="auctionPanel center"><h2>چند دست می‌خوای اعلام کنی؟</h2><div className="auctionWho"><span>نوبت</span><b>{players[state.auctionIndex]?.name}</b><span className="countdown">{state.countdown}</span></div>{state.bid&&<div className="currentBid">بالاترین اعلام <strong>{state.bid}</strong></div>}<div className="choices">{[6,7,8].map(v=><button key={v} className={state.bid===v?'bidSelected':''} disabled={state.bid&&v<=state.bid} onClick={()=>act(()=>controller.submitBid(state.auctionIndex,v))}>{v}</button>)}<button className="pass" onClick={()=>act(()=>controller.submitBid(state.auctionIndex,'pass'))}>پاس</button></div><small className="auctionHint">۱۰ ثانیه فرصت اعلام</small></div>}
  {state.phase==='surrender'&&<Center title="حاکم انتخاب نشده"><p>حاکم نمی‌تواند پاس بدهد.</p><button className="gold" onClick={()=>act(controller.surrender)}>واگذاری ۶۰ امتیاز</button><div className="choices"><button onClick={()=>act(()=>controller.submitBid(state.dealer,6))}>۶</button><button onClick={()=>act(()=>controller.submitBid(state.dealer,7))}>۷</button><button onClick={()=>act(()=>controller.submitBid(state.dealer,8))}>۸</button></div></Center>}
  {state.phase==='trump'&&<Center title="حکم را انتخاب کن"><p>حاکم: <b>{players[state.declarer]?.name}</b></p><div className="choices suitChoices">{SUITS.map(s=><button className="suit" onClick={()=>act(()=>controller.chooseTrump(state.declarer,s))}>{s.s}<small>{s.name}</small></button>)}</div></Center>}
  {state.phase==='kot'&&<Center title="کُت می‌کنی؟"><p>اگر بله بگویی، باید همه دورهای باقی‌مانده را ببری.</p><button className="gold" onClick={()=>act(()=>controller.answerKot(state.declarer,true))}>بله، کُت</button><button onClick={()=>act(()=>controller.answerKot(state.declarer,false))}>خیر</button></Center>}
  {state.phase==='play'&&<><div className="trickArea">{state.trick.map(x=><div key={x.card.id} className="played"><small>{players[x.playerId].name}</small><CardFace card={x.card} compact/></div>)}</div><div className="turn">نوبت: <b>{players[state.current]?.name}</b></div></>}
  {showHumanHand&&<div className="hand">{hand.map(c=><button key={c.id} disabled={state.phase!=='play'||!playable(c)} className={selected===c.id?'selected':''} onClick={()=>{if(state.phase!=='play')return;setSelected(c.id);setTimeout(()=>act(()=>controller.playCard(human.id,c)),160)}}><CardFace card={c}/></button>)}</div>}
  {state.phase==='blackLoss'&&<Center title="باخت با جوکر سیاه"><p>جوکر سیاه تا پایان دور سوم بازی نشد.</p><p>این بازی به پایان رسید.</p><button className="gold" onClick={onHome}>صفحه اصلی</button></Center>}
  {state.phase==='kotLoss'&&<Center title="کُت از دست رفت"><p>یکی از دورهای باقی‌مانده به تیم حاکم نرسید.</p><p>بازی با باخت تیم حاکم تمام شد.</p><button className="gold" onClick={onHome}>صفحه اصلی</button></Center>}
  {state.phase==='kotWin'&&<Center title="برد با کُت! 👑"><p>حاکم هر ۹ دور را برد.</p><p>قهرمان بازی: {players.find(p=>p.team===state.winner)?.name || 'تیم حاکم'}</p><button className="gold" onClick={()=>setProfile({...profile,kotWins:profile.kotWins+1,wins:profile.wins+1})}>ثبت برد و پایان</button></Center>}
  {state.phase==='handEnd'&&<Center title="پایان دور"><p>نتیجه ثبت شد.</p><button className="gold" onClick={onHome}>پایان</button></Center>}
 </div></div>
}
function DealOverlay(){return <div className="dealStage"><div className="dealDeck"><span>♛</span><small>۵۴ کارت</small></div><div className="dealLabel">در حال پخش ۹ کارت برای ۶ بازیکن…</div></div>}
const FAN_TARGETS=[['0px','245px'],['175px','125px'],['175px','-165px'],['0px','-235px'],['-175px','-165px'],['-175px','125px']];
function DealFannedHands({players,hands,settled=false}){return <div className={`dealFans ${settled?'settled':''}`}>{players.map((p,pi)=>p.human?null:<div key={p.id} className={`dealFan fan${p.id}`} style={{'--fx':FAN_TARGETS[pi][0],'--fy':FAN_TARGETS[pi][1]}}>{(hands[p.id]||[]).slice(0,9).map((c,i)=><div key={c.id} className="dealFanCard" style={{'--i':i}}><CardFace card={c} back compact/></div>)}</div>)}</div>}
function HumanDealHand({hand,settled=false}){return <div className={`humanDealHand ${settled?'settled':''}`}>{hand.slice(0,9).map((c,i)=><div key={c.id} className="humanDealCard" style={{'--i':i}}><CardFace card={c}/></div>)}</div>}
function DealReadyOverlay({state,ready=false,onStart}){return <div className={`dealReadyOverlay ${ready?'ready':''}`}><div className="viewCountdown">{state.countdown}</div>{ready?<><strong>کارت‌ها آماده است</strong><button className="gold" onClick={onStart}>شروع اعلام</button></>:<span>کارت‌های تو آماده شد</span>}</div>}
function Center({title,children}){return <div className="center"><h2>{title}</h2>{children}</div>}
function Wifi({onBack,wifi,setWifi}){const [busy,setBusy]=useState(false);const create=async()=>{setBusy(true);try{const {createHost}=await import('./network/host.js');const h=await createHost();setWifi({mode:'host',pc:h.pc,offer:JSON.stringify(h.offer),answer:'',transport:h.transport})}catch(e){setWifi({...wifi,error:'این مرورگر اجازه اتصال مستقیم Wi‑Fi را نداد.'})}finally{setBusy(false)}};const makeAnswer=async()=>{try{const {createClient}=await import('./network/client.js');const c=await createClient(JSON.parse(wifi.offer));setWifi({...wifi,mode:'client',answer:JSON.stringify(c.answer),transport:c.transport})}catch(e){setWifi({...wifi,error:'کد میزبان نامعتبر است یا اتصال محلی برقرار نشد.'})}};const accept=async()=>{try{const {acceptAnswer}=await import('./network/host.js');await acceptAnswer(wifi.pc,JSON.parse(wifi.answer));setWifi({...wifi,connected:true})}catch(e){setWifi({...wifi,error:'پاسخ اتصال نامعتبر است.'})}};return <Page title="بازی با دوستان (Wi‑Fi)" back={onBack}><p>اتصال محلی بدون اینترنت؛ برای آزمایش، کد میزبان را بین دو گوشی جابه‌جا کنید.</p><button className="gold" onClick={create} disabled={busy}>{busy?'در حال ساخت...':'ساخت اتاق میزبان'}</button><h3>ورود به اتاق</h3><textarea placeholder="کد میزبان را اینجا وارد کنید" value={wifi.mode==='client'?'':wifi.joinOffer||''} onChange={e=>setWifi({...wifi,joinOffer:e.target.value,offer:e.target.value})}/><button onClick={makeAnswer}>ساخت پاسخ</button>{wifi.offer&&<><h3>کد اتصال</h3><textarea value={wifi.offer} readOnly/><h3>پاسخ</h3><textarea value={wifi.answer} onChange={e=>setWifi({...wifi,answer:e.target.value})}/><button onClick={accept}>تأیید پاسخ میزبان</button></>}{wifi.connected&&<p>اتصال برقرار شد.</p>}{wifi.error&&<p className="error">{wifi.error}</p>}</Page>}
createRoot(document.getElementById('root')).render(<App/>);
